# @midas/client

Universal developer SDK and first-party React components for **MIDAS Autonomous Outbound & Town Crier Newsletters**.

---

## 1. Installation

```bash
npm install @midas/client
# or
yarn add @midas/client
# or
pnpm add @midas/client
2. React / Next.js 1-Line Drop-In Modal
Tsx
import { MidasModal } from '@midas/client/react';

export default function HeroSection() {
  return (
    <MidasModal
      gongId="weekly-alpha"
      developerToggle
      accent="#7C3AED"
      className="px-6 py-3 bg-purple-600 text-white font-bold rounded-xl"
    >
      Join 15,000+ Founders
    </MidasModal>
  );
}
3. Isomorphic Backend / Node.js Usage
Automatically reads process.env.MIDAS_API_KEY:
TypeScript
import { MidasClient } from '@midas/client';

// Zero arguments needed in environments with MIDAS_API_KEY defined
const midas = new MidasClient();

await midas.subscribe({
  email: 'subscriber@acme.com',
  name: 'Alex Mercer',
  gongId: 'weekly-alpha',
  cadence: 'weekly',
  metadata: { isTechnicalFounder: true }
});
4. Props Reference (<MidasModal />)
Prop	Type	Default	Description
gongId	string	undefined	Target Gong publication channel ID or slug.
developerToggle	boolean	false	Enables progressive profiling toggle that reveals GitHub URL input.
cadenceToggle	boolean	true	Enables interactive frequency pills (Daily, Weekly, Monthly).
accent	string	#2563EB	Hex color code for submit button & active focus rings.
fields	string[]	['name', 'email']	Array of field tokens to collect dynamically.
headline	string	'Join our Newsletter'	Main heading in modal dialog.
subheadline	string	'Get updates...'	Supporting lead magnet or discount copy.
buttonText	string	'Subscribe'	Label on submit button.